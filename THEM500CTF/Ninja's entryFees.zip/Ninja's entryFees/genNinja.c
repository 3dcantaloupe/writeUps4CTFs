#include <stdlib.h>
#include <stdio.h>
#include <time.h>

//Return a byte at a time of the rand() keystream
char randchar() {
  static int key;
  static int i = 0;
  i = i % 4;
  if (i == 0) key = rand();
  return ((char *)(&key))[i++];
}

int main(int argc, const char* argv[]) {
  static char randstate[64];
  initstate(time(NULL),randstate,31);

  FILE *input, *output;
  input = fopen("ninja.hex", "r");
  output = fopen("ninja.hex.enc", "w");

  FILE *key = fopen("key", "w");

  int c;
  while ((c = fgetc(input)) != EOF){
    char stream = randchar();
    fputc(c^stream,output);
    fputc(stream,key);
  }
  fclose(input);
  fclose(output);
  fclose(key);
}